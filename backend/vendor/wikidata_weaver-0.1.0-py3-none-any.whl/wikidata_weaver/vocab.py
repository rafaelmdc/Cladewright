"""Capabilities and manifest for the weaver — generated from weaver.spec.toml.

The manifest is the machine-readable mirror of the spec; keep them in sync
(``weaverkit verify`` checks this). Edit the spec and regenerate rather than
hand-editing capabilities here.
"""

from __future__ import annotations

from braidworks.core import (
    Capability,
    OutputGroup,
    Parameter,
    Provenance,
    WeaverManifest,
)

WEAVER_ID = "wikidata"
WEAVER_VERSION = "0.1.0"
WEAVER_TITLE = "Wikidata taxon names (scientific name -> QID, vernacular names, enwiki title)"

# Source/license/citation for automatic references — mirrors weaver.spec.toml.
PROVENANCE = Provenance(
    source_url="https://www.wikidata.org/",
    license="CC0-1.0",
    citation="Wikidata, the free knowledge base. https://www.wikidata.org/",
    attribution="Wikidata contributors (CC0)",
)


def build_manifest(*, backends: tuple[str, ...]) -> WeaverManifest:
    """Declare every capability for the wired-in backends."""
    return WeaverManifest(
        weaver_id=WEAVER_ID,
        version=WEAVER_VERSION,
        title=WEAVER_TITLE,
        provenance=PROVENANCE,
        capabilities=(
            Capability(
                id="resolve_taxon",
                consumes=frozenset({"organism.scientific_name"}),
                produces=frozenset(
                    {"organism.vernacular_names", "wikidata.qid", "wikipedia.title"}
                ),
                output_groups=(
                    OutputGroup(id="core", outputs=frozenset({"wikidata.qid", "wikipedia.title"})),
                    OutputGroup(id="names", outputs=frozenset({"organism.vernacular_names"})),
                ),
                backends=("api",),
                always_computed_groups=frozenset({"core"}),
            ),
        ),
    )
